#!/bin/bash

# ONLYOFFICE 解析服務測試腳本

echo "=== ONLYOFFICE 解析服務測試 ==="
echo ""

# 1. 健康檢查
echo "1. 健康檢查..."
curl -s http://localhost:8005/health | jq .
echo ""

# 2. 解析範本測試
echo "2. 解析範本測試..."
echo "請確保有測試文檔: /tmp/test_template.docx"
echo ""

if [ -f "/tmp/test_template.docx" ]; then
    echo "發送解析請求..."

    curl -X POST http://localhost:8005/parse-template \
      -F "file=@/tmp/test_template.docx" \
      -F "supabase_url=${NEXT_PUBLIC_SUPABASE_URL}" \
      -F "supabase_key=${NEXT_PUBLIC_SUPABASE_ANON_KEY}" \
      | jq '.' > /tmp/parse_result.json

    echo "✅ 解析完成！結果保存在: /tmp/parse_result.json"
    echo ""
    echo "段落數量:"
    jq '.paragraphs | length' /tmp/parse_result.json
else
    echo "⚠️  測試文檔不存在: /tmp/test_template.docx"
    echo "請準備一個測試文檔後重試"
fi

echo ""
echo "=== 測試完成 ==="
